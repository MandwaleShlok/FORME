# FORME. – Wear Your Perspective

A six-page fashion editorial site built with **HTML + CSS only (no JavaScript)**, using Bootstrap 5 for the grid.

Pages: Home · Trends · Collections · Outfit Ideas · Style Guide · Feedback

## Run locally
Open `index.html` in a browser (internet needed for Bootstrap and Google Fonts).

## Structure
- `*.html` – the six pages
- `css/style.css` – custom styles
- `images/` – photos used on the pages
